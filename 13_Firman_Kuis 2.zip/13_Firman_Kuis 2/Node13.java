public class Node13 {
   Mahasiswa13 data;
    Node13 next;
        
    public Node13(Mahasiswa13 data) {
        this.data = data;
        this.next = null;
    }
}
    

