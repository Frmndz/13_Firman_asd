package UAS;
public class TransaksiRental {
    private String kodeTransaksi;
    private BarangRental barangRental;
    private String namaPeminjam;
    private int lamaPinjam;
    private double totalBiaya;


    public TransaksiRental(String kodeTransaksi, BarangRental barangRental, String namaPeminjam, int lamaPinjam) {
        this.kodeTransaksi = kodeTransaksi;
        this.barangRental = barangRental;
        this.namaPeminjam = namaPeminjam;
        this.lamaPinjam = lamaPinjam;
        this.totalBiaya = lamaPinjam * barangRental.getBiayaSewa();
    }

 
    public kodeTransaksi getKodeTransaksi() {
        return kodeTransaksi;
    }

    public BarangRental getBarangRental() {
        return barangRental;
    }

    public String getNamaPeminjam() {
        return namaPeminjam;
    }

    public int getLamaPinjam() {
        return lamaPinjam;
    }

    public double getTotalBiaya() {
        return totalBiaya;
    }
}
