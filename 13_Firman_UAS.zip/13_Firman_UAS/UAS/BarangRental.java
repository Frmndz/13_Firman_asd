package UAS;

public class BarangRental {
    private String noTNKB;
    private String namaKendaraan;
    private String jenisKendaraan;
    private int tahun;
    private double biayaSewa;

    // Konstruktor
    public BarangRental(String noTNKB, String namaKendaraan, String jenisKendaraan, int tahun, double biayaSewa) {
        this.noTNKB = noTNKB;
        this.namaKendaraan = namaKendaraan;
        this.jenisKendaraan = jenisKendaraan;
        this.tahun = tahun;
        this.biayaSewa = biayaSewa;
    }

    public void setNoTNKB(String noTNKB) {
        this.noTNKB = noTNKB;
    }

    public void setNamaKendaraan(String namaKendaraan) {
        this.namaKendaraan = namaKendaraan;
    }

    public void setJenisKendaraan(String jenisKendaraan) {
        this.jenisKendaraan = jenisKendaraan;
    }

    public void setTahun(int tahun) {
        this.tahun = tahun;
    }

    public void setBiayaSewa(double biayaSewa) {
        this.biayaSewa = biayaSewa;
    }

    // Metode untuk menampilkan informasi kendaraan
    public void tampilkanInfo() {
        System.out.println(noTNKB + " - " + namaKendaraan + " - " + jenisKendaraan + " - " + tahun + " - Rp" + biayaSewa);
    }
}