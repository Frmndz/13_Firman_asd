package UAS;
import java.util.Scanner;

public class RentalMain {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int pilihan;

        BarangRental barangrental = new BarangRental();

        barangrental.tambahKendaraan(new BarangRental("TNKB001", "Toyota Avanza", "Mobil", 2015, 500000));
        r.tambahKendaraan(new BarangRental("TNKB002", "Honda Scoopy", "Motor", 2018, 200000));

        do {
            System.out.println("***** Sistem Penyewaan Kendaraan *****");
            System.out.println("1. Daftar Kendaraan");
            System.out.println("2. Peminjaman Kendaraan");
            System.out.println("3. Tampilkan Seluruh Unit No TNKB");
            System.out.println("4. Transaksi Terakhir");
            System.out.println("5. Keluar");
            System.out.print("Masukkan pilihan Anda: ");
            pilihan = scanner.nextInt();

            switch (pilihan) {
                case 1:
                    barangrental.tampilkanDaftarKendaraan();
                    break;
                case 2:
                    barangrental.pinjamKendaraan();
                    break;
                case 3:
                    barangrental.tampilkanSemuaUnitTNKB();
                    break;
                case 4:
                    barangrental.tampilkanTransaksiTerakhir();
                    break;
                case 5:
                    System.out.println("Terima kasih telah menggunakan sistem penyewaan kami.");
                    break;
                default:
                    System.out.println("Pilihan tidak valid. Silakan coba lagi.");
            }
        } while (pilihan != 5);

        scanner.close();
    }
}